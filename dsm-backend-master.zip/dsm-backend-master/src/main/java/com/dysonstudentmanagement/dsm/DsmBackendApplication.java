package com.dysonstudentmanagement.dsm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsmBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsmBackendApplication.class, args);
	}

}
